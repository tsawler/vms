﻿FCKLang.PlaceholderBtn			= 'Insert/Edit Placeholder' ;
FCKLang.PlaceholderDlgTitle		= 'Placeholder Properties' ;
FCKLang.PlaceholderDlgName		= 'Placeholder Name' ;
FCKLang.PlaceholderErrNoName	= 'Please type the placeholder name' ;
FCKLang.PlaceholderErrNameInUse	= 'The specified name is already in use' ;